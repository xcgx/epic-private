---
name: Bug report
about: Use this template for reporting a bug. Please SEARCH before posting!
title: "(CHANGE THIS!) A Descriptive Title"
labels: bug
---

### Expected Behavior


### Actual Behavior


### Steps to Reproduce the Problem

  1. 
  2. 
  3. 


### Specifications

  - `epicgames-freebies-claimer` Version: 
  - Platform / OS: 
  - Node Version: 
